#include<bits/stdc++.h>
using namespace std;

int main(){
	long long int  n,  k  , ans;
	cin >> n >> k;
	ans = (n+k-1)/n;
	cout<< ans << endl;
	return 0;
}
