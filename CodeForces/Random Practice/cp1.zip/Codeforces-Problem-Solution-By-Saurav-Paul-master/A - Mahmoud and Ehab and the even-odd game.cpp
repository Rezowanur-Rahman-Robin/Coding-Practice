#include<iostream>
using namespace std;
int main(){
long long int n;
cin>>n;
if(n%2!=0)
    cout<<"Ehab"<<endl;
else
    cout<<"Mahmoud"<<endl;


return 0;
}
