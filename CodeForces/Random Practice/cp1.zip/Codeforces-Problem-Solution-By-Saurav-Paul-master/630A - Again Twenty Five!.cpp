#include<iostream>
using namespace std;
int main(){
    
    cout<<25<<endl;
    
    return 0;
}
