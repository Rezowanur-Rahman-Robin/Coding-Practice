#include<bits/stdc++.h>
using namespace std;
int main(){
	long long int n;
	scanf("%lld",&n);
	((n==2)?n=2 : n=1);
	printf("%lld\n",n);
	
	return 0;
}
