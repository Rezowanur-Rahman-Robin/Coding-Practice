
/**
 *    author:  Saurav_Paul 
 *    created: 10.01.2020 20:05:58       
**/

#include<bits/stdc++.h>
using namespace std;


int main()
{
	int n ;
	cin >> n;
	string s; 
	cin >> s;
	cout << n + 1 << endl;

    return 0;
}
