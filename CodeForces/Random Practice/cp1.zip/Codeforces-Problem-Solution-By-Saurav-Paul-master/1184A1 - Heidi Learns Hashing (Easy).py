r = int(input())
y = int((r-3)/2)
if(r&1 and y > 0):
	print("{} {}".format(1,y))
	
else :
	print("NO")
