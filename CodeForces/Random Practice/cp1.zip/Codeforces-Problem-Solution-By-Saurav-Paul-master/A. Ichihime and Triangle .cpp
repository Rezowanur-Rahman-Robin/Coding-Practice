
/**
 *    author:  Saurav_Paul 
 *    created: 15.04.2020 20:42:14       
**/

#include<bits/stdc++.h>
using namespace std;

void solve() {

    long long a , b , c, d;
    cin >> a >> b >> c >> d;
    cout << b << " " << c << " " << c << endl ;
}

int main(){

    ios_base::sync_with_stdio(false);
    cin.tie(0);
    
    int testcase;
    cin >> testcase;
    for (int t = 1; t <= testcase; t++){
        solve();
    }

    return 0;
}
