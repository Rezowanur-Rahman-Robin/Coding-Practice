#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    cin>>s;
    putchar(toupper(s[0]));
    for(int i=1; i<s.length(); i++){
        cout<<s[i];
    }
    cout<<"\n";
    return 0;
}
/*
SIMPLE INPUT
ApPLe
*/
