#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,n;
    cin>>t;
    while(t--){
        int ans=0;
        cin>>n;
//        for(int i=7; i>1; i--){
//            ans+=n/i;
//            n=n%i;
//        }
        cout<<n/2<<endl;
    }
}
