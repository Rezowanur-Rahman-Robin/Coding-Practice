#include<iostream>
using namespace std;
int main()
{
    long long int n;
    cin>>n;
    if(n==1)
        cout<<9<<" "<<8<<endl;
    else
        cout<<n*4<<" "<<n*3<<endl;

    return 0;
}
