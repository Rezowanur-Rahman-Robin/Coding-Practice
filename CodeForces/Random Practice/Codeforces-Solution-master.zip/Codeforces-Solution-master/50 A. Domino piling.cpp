#include<iostream>

using namespace std;
int a,b,sum;
int main()
{
    cin>>a>>b;
    sum=(a*b)/2;
    cout<<sum;

    return 0;
}
