//Bismillahir Rahmanir Rahim
#include<bits/stdc++.h>
#define ll              long long
#define ull             unsigned long long
#define pb              push_back
#define fastread()      (ios_base:: sync_with_stdio(false),cin.tie(NULL));
using namespace std;
int main()
{
    fastread();
    int n;
    cin>>n;

    cout<<n<<endl;
    for(int i=0; i<n; i++){
        cout<<1<<" ";
    }cout<<endl;

    return 0;
}

