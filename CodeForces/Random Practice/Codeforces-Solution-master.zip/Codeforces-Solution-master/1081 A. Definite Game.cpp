//Bismillahir Rahmanir Rahim
#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
using namespace std;
int main()
{
    int n;
    cin>>n;
    if(n == 2){
        cout<<n<<endl;
    }
    else
        cout<<1<<endl;

    return 0;
}

