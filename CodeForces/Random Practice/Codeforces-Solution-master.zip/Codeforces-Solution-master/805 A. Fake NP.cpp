#include<bits/stdc++.h>
#define ll              long long
#define ull             unsigned long long
#define pb              push_back
#define fastread()      (ios_base:: sync_with_stdio(false),cin.tie(NULL));
using namespace std;
int main()
{
    fastread();
    //freopen("input.txt","r", stdin);

    ll l,r;
    cin>>l>>r;

    if(l == r){
        cout<<l<<endl;
    }
    else{
        cout<<2<<endl;
    }

    return 0;
}
