#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    long long int a,b,c,d;
    cin>>t;
    while(t--)
    {
        cin>>a>>b>>c>>d;
        cout<<b<<" "<<c<<" "<<c<<endl;
    }
    return 0;
}
/*
SIMPLR INPUT
4
1 3 5 7
1 5 5 7
100000 200000 300000 400000
1 1 977539810 977539810
*/
