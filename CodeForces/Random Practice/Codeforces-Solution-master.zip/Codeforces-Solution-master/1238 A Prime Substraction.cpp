#include<bits/stdc++.h>
using namespace std;

void solve()
{

    long long a,b;
    cin>>a>>b;
    if((a-b)>1)
        cout<<"YES\n";
    else
        cout<<"NO\n";

}
int main()
{

    int t;
    t=1;
    cin>>t;
    while(t--)
    {
        solve();
    }
    return 0;
}
