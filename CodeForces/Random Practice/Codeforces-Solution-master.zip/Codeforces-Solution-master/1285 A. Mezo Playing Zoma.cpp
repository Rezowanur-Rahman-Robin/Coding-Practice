#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long int n;
    string s;

    cin>>n;
    cin>>s;
    cout<<n+1<<endl;

    return 0;
}
