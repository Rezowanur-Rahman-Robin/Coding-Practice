const routes = {
  '/oauth': 'http://localhost:3001',
  '/graph': 'http://localhost:3002',
  '/api': 'http://localhost:3003',
  '/events': 'http://localhost:3004',
  '/': 'http://localhost:3005'
};
module.exports = routes