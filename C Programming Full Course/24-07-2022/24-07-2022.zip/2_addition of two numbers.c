#include<stdio.h>
int main(){

/// Average Result of course code 5 and 4 is : 5.00 ( A )

/*
Average Result of course

code 5 and 4 is : 5.00

*/
int name_10;
int fahmida,mourin,result;
char grade='A';
float gpa=5.00;
fahmida=5;
mourin=4;
result = fahmida + mourin;
/// Average Result of course code 5 and 4 is : 5.00 ( A )

printf("Average Result of course code %d and %d is: %.2f ( %c ) ",fahmida,mourin,gpa,grade);

return 0;
}
