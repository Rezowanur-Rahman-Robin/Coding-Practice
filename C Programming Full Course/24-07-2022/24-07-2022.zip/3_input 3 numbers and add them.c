#include<stdio.h>
int main(){

int a,b,c,result;
/*
printf("Enter three numbers:");
scanf("%d %d %d",&a,&b,&c);
*/

printf("Enter first number:");
scanf("%d",&a);

printf("Enter Second Number:");
scanf("%d",&b);

printf("Enter third Number:");
scanf("%d",&c);

result = a+b+c;

printf("Result: %d",result);


return 0;
}
