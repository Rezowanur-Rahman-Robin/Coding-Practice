#include<stdio.h>
int main(){

printf("Some ASCII of of some characters:\n\n");

char myChar = 'a';
char myChar1 = 'A';
char myChar2 = '1';
char myChar3 = ' ';



printf("The ASCII value of %c is : %d\n",myChar,myChar);

printf("The ASCII value of %c is : %d\n",myChar1,myChar1);

printf("The ASCII value of %c is : %d\n",myChar2,myChar2);

printf("The ASCII value of %c is : %d\n",myChar3,myChar3);



return 0;
}
