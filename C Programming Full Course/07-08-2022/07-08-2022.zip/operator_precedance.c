
#include<stdio.h>
int main(){

int A=20;
A += 16 * 4 - 4 >> 2;


printf("%d \n",A);

int B;

B=(60 & (5+(3+5)));
B--;

printf("%d \n",B);

return 0;
}
